package tarena.day1504;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

	private TextView tv;
	private Button bt;
	private EditText et2;
	private EditText et1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		setViews();
		setListeners();
	}

	private void setViews() {
		et1 = (EditText) findViewById(R.id.et1);
		et2 = (EditText) findViewById(R.id.et2);
		bt = (Button) findViewById(R.id.bt1);
		tv = (TextView) findViewById(R.id.tv1);
	}

	private void setListeners() {
		bt.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				f();
			}
		});
	}

	protected void f() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
