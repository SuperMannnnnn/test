/** Automatically generated file. DO NOT MODIFY */
package tarena.day1504;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}