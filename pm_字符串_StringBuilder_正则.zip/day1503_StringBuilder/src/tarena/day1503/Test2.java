package tarena.day1503;

public class Test2 {
	public static void main(String[] args) {
		StringBuilder sb = 
		 new StringBuilder("abc");
		
		sb.append("def")//abcdef
		  .append("ghi")//abcdefghi
		  .insert(5, "xyz")//abcdexyzfghi
		  .replace(3, 5, ">>><<<")//abc>>><<<xyzfghi
		  .reverse()//ihgfzyx<<<>>>cba
		  .delete(2, 6)//ihx<<<>>>cba
		  .deleteCharAt(0)//hx<<<>>>cba
		  .setCharAt(5, '5');//hx<<<5>>cba
		
		System.out.println(sb);
	}
}
