package tarena.day1505;

import java.util.Scanner;

public class Test2 {
	public static void main(String[] args) {
		System.out.println(
		 "�ؼ����б����ö��š��ֺŻ�ո�ָ���");
		String s = 
		 new Scanner(System.in).nextLine();
		
		//we,sd;er wr,,,et   ,;,;;;,,  ;;,,ert
		
		String regex = "[,; ]+";
		String[] a = s.split(regex);
		for(int i=0;i<a.length;i++) {
			System.out.println(a[i]);
		}
	}
}
