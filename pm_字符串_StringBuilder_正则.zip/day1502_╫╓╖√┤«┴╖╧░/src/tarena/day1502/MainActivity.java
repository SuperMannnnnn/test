package tarena.day1502;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

	private TextView tv;
	private Button bt3;
	private Button bt2;
	private Button bt1;
	private EditText et;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		setViews();
		setListeners();
	}

	private void setViews() {
		et = (EditText) findViewById(R.id.et1);
		bt1 = (Button) findViewById(R.id.bt1);
		bt2 = (Button) findViewById(R.id.bt2);
		bt3 = (Button) findViewById(R.id.bt3);
		tv = (TextView) findViewById(R.id.tv);
	}

	private void setListeners() {
		bt1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				f1();
			}
		});
		bt2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				f2();
			}
		});
		bt3.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				f3();
			}
		});
	}

	protected void f1() {
		String s = et.getText().toString();
		// abc@def.com
		int index = s.indexOf("@");
		if(index == -1) {
			tv.setText("email��ʽ����");
			return;
		}
		String name = s.substring(0, index);
		tv.setText(name);
		
	}

	protected void f2() {
		String s = et.getText().toString();
		/* abcdedxba
		 *   i   j */
		boolean b = true;//�����ǻ���
		for(int i=0,j=s.length()-1; i<j; i++,j--) {
			if(s.charAt(i) != s.charAt(j)) {
				b = false;//���ǻ���
				break;
			}
		}
		
		tv.setText(b?"�ǻ���":"���ǻ���");
	}

	
	protected void f3() {
		String s = et.getText().toString();
		/*
		 * abcdef
		 *   i
		 * 
		 * "fedc"
		 */
		String r = "";
		for(int i=s.length()-1;i>=0;i--) {
			r += s.charAt(i);
		}
		tv.setText(r);
	}
	
	
	
	
	
	
	
	
	

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
