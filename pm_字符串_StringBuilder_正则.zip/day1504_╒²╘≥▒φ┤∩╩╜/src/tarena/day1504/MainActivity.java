package tarena.day1504;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

	private TextView tv;
	private Button bt;
	private EditText et2;
	private EditText et1;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		setViews();
		setListeners();
	}

	private void setViews() {
		et1 = (EditText) findViewById(R.id.et1);
		et2 = (EditText) findViewById(R.id.et2);
		bt = (Button) findViewById(R.id.bt1);
		tv = (TextView) findViewById(R.id.tv1);
	}

	private void setListeners() {
		bt.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				f();
			}
		});
	}

	
	
	protected void f() {
		String id = et1.getText().toString();
		String tel = et2.getText().toString();
		
		boolean b = true;//�����ʽ����ȷ
		if(! checkId(id)) {
			tv.append("\n����֤��ʽ����");
			b = false;
		}
		if(! checkTel(tel)) {
			tv.append("\n���������ʽ����");
			b = false;
		}
		
		if(b) {
			tv.setText("��ʽ��ȷ");
		}
	}
	
	
	
	
	
	
	
	
	
	
	

	private boolean checkId(String id) {
		/*
		 * 123456789012345 
		 * 123456789012345678
		 * 12345678901234567x
		 * 12345678901234567X
		 * 
		 * |
		 * \d{15}|
		 * \d{15}|\d{17}
		 * \d{15}|\d{17}[\dxX]
		 * 
		 * \\d{15}|\\d{17}[\\dxX]
		 */
		String regex = "\\d{15}|\\d{17}[\\dxX]";
		return id.matches(regex);
	}

	
	
	
	
	
	
	
	
	
	private boolean checkTel(String tel) {
		/*
		 * 1234567
		 * 12345678
		 * 010-1234567
		 * 0102-12345678
		 * (0102)12345678
		 * (010)1234567
		 * 
		 * \d{7,8}
		 * ()?\d{7,8}
		 * (|)?\d{7,8}
		 * (\d{3,4}-|)?\d{7,8}
		 * (\d{3,4}-|\(\))?\d{7,8}
		 * (\d{3,4}-|\(\d{3,4}\))?\d{7,8}
		 * 
		 * (\\d{3,4}-|\\(\\d{3,4}\\))?\\d{7,8}
		 */
		String regex = 
		 "(\\d{3,4}-|\\(\\d{3,4}\\))?\\d{7,8}";
		return tel.matches(regex);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
