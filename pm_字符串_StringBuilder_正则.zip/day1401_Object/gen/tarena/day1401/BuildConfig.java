/** Automatically generated file. DO NOT MODIFY */
package tarena.day1401;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}