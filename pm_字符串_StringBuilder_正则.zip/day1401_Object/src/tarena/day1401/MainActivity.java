package tarena.day1401;

import android.os.Bundle;
import android.app.Activity;
import android.view.Menu;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends Activity {

	private TextView tv;
	private Button bt2;
	private Button bt1;
	private EditText et2;
	private EditText et1;
	private Point p1;
	private Point p2;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_main);
		
		setViews();
		setListeners();
	}

	private void setViews() {
		et1 = (EditText) findViewById(R.id.et1);
		et2 = (EditText) findViewById(R.id.et2);
		bt1 = (Button) findViewById(R.id.bt1);
		bt2 = (Button) findViewById(R.id.bt2);
		tv = (TextView) findViewById(R.id.tv1);
	}
	private void setListeners() {
		bt1.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				f1();
			}
		});
		bt2.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				f2();
			}
		});
	}

	protected void f1() {
		int x = Integer.parseInt(
				et1.getText().toString());
		int y = Integer.parseInt(
				et2.getText().toString());
		
		p1 = new Point(x, y);
		showPoint();
	}

	protected void f2() {
		int x = Integer.parseInt(
				et1.getText().toString());
		int y = Integer.parseInt(
				et2.getText().toString());
		
		p2 = new Point(x, y);
		showPoint();
	}

	private void showPoint() {
		String s = 
		 "\n��1��"+p1+//�Զ�����p1.toString()��õ������ַ�����ʾ
		 "\n��2��"+p2+
		 "\n==�Ƿ���ȣ�"+(p1==p2)+
		 "\nequals�Ƿ���ȣ�"+(p1.equals(p2));
		
		tv.setText(
		 s+"\n==========\n"+tv.getText());
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.main, menu);
		return true;
	}

}
