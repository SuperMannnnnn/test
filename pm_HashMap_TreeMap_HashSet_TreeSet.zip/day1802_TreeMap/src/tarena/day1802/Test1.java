package tarena.day1802;

import java.util.TreeMap;

public class Test1 {
	public static void main(String[] args) {
		TreeMap<Integer, String> map = new TreeMap<>();
		map.put(888, "8");
		map.put(222, "2");
		map.put(999, "9");
		map.put(111, "1");
		map.put(666, "6");
		map.put(333, "3");
		System.out.println(map);
	}
}
