package tarena.day1802;

import java.util.Comparator;
import java.util.TreeMap;

public class Test2 {
	public static void main(String[] args) {
		Point a = new Point(1, 23);
		Point b = new Point(2, 29);
		
		Comparator<Point> comp = 
		 new Comparator<Point>() {
			/*
			 * o1��o2�Ƚϴ�С��
			 * o1������
			 * o1С������
			 * ��ͬ��0
			 */
			@Override
			public int compare(
					Point o1, 
					Point o2) {
				return o2.getY()-o1.getY();  
			}
		};
		
		
		
		TreeMap<Point, String> map = 
				new TreeMap<>(comp);
		
		
		map.put(a, "2.3��");
		map.put(b, "2.9��");
		
		System.out.println(map);
	}
}
