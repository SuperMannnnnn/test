package tarena.day1803;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;
import java.util.TreeSet;

public class Test1 {
	public static void main(String[] args) {
		Set<Integer> set;
		//set = new HashSet<Integer>();
		set = new TreeSet<Integer>();
		set.add(9999);
		set.add(3333);
		set.add(5555);
		set.add(7777);
		set.add(1111);
		System.out.println(set.size());
		System.out.println(set);
		System.out.println(set.contains(333));
		System.out.println(set.remove(555));
		System.out.println(set);
		//�������������Լ�д
		//д��ɾ��ɾ��д���ֳ�����һ���Ƴ�
		Iterator<Integer> it = set.iterator();    
		while(it.hasNext()) {
			Integer i = it.next();
			System.out.println(i);
		}
		
		
		
		
		
	}
}




