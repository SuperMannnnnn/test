package tarena.day1801;

import java.util.HashMap;

public class Test3 {
	public static void main(String[] args) {
		Student s1 = new Student(9527,"����","��",22);
		Student s2 = new Student(9527,"����","��",22);
		
		System.out.println(s1.hashCode());
		System.out.println(s2.hashCode());
		System.out.println(s1.equals(s2));
		
		HashMap<Student, Integer> map = new HashMap<>();
		map.put(s1, 97);
		map.put(s2, 95);
		
		System.out.println(map);
		
		
	}
}







